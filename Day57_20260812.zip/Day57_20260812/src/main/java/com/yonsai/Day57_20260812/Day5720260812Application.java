package com.yonsai.Day57_20260812;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day5720260812Application {

	public static void main(String[] args) {
		SpringApplication.run(Day5720260812Application.class, args);
	}

}
